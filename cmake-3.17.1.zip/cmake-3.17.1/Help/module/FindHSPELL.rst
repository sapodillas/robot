.. cmake-module:: ../../Modules/FindHSPELL.cmake
