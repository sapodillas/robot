.. cmake-module:: ../../Modules/FindLAPACK.cmake
